<?xml version="1.0" encoding="UTF-8"?>
<sch:schema xmlns:sch="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
  <sch:ns prefix="f" uri="http://hl7.org/fhir"/>
  <sch:ns prefix="h" uri="http://www.w3.org/1999/xhtml"/>
  <!-- 
    This file contains just the constraints for the profile Flag
    It includes the base constraints for the resource as well.
    Because of the way that schematrons and containment work, 
    you may need to use this schematron fragment to build a, 
    single schematron that validates contained resources (if you have any) 
  -->
  <sch:pattern>
    <sch:title>f:Flag</sch:title>
    <sch:rule context="f:Flag">
      <sch:assert test="count(f:extension[@url = 'https://fhir.speirotech.net/StructureDefinition/flag-severity']) &gt;= 1">extension with URL = 'https://fhir.speirotech.net/StructureDefinition/flag-severity': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'https://fhir.speirotech.net/StructureDefinition/flag-severity']) &lt;= 1">extension with URL = 'https://fhir.speirotech.net/StructureDefinition/flag-severity': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'https://fhir.speirotech.net/StructureDefinition/flag-scope']) &gt;= 1">extension with URL = 'https://fhir.speirotech.net/StructureDefinition/flag-scope': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'https://fhir.speirotech.net/StructureDefinition/flag-scope']) &lt;= 1">extension with URL = 'https://fhir.speirotech.net/StructureDefinition/flag-scope': maximum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'https://fhir.speirotech.net/StructureDefinition/blocking']) &gt;= 1">extension with URL = 'https://fhir.speirotech.net/StructureDefinition/blocking': minimum cardinality of 'extension' is 1</sch:assert>
      <sch:assert test="count(f:extension[@url = 'https://fhir.speirotech.net/StructureDefinition/blocking']) &lt;= 1">extension with URL = 'https://fhir.speirotech.net/StructureDefinition/blocking': maximum cardinality of 'extension' is 1</sch:assert>
    </sch:rule>
  </sch:pattern>
</sch:schema>
